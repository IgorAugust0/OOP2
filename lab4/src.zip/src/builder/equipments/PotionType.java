package builder.equipments;

/**
 * Enum que representa os tipos de poções.
 */
public enum PotionType {
    HEALTH, MANA, STRENGTH, DEXTERITY
}
