package builder.equipments;

/**
 * Enum que representa os tipos de anéis.
 */
public enum RingType {
    HEALTH, STRENGTH, DEFENSE, INTELLIGENCE, DEXTERITY
}
