package builder.equipments;

/**
 * Enum que representa os tipos de itens.
 */
public enum ItemType {
    POTION, ITEM
}
