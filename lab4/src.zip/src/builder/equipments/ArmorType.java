package builder.equipments;

/**
 * Enum que representa os tipos de armaduras.
 */
public enum ArmorType {
    SHIELD, HELMET, CHESTPLATE, LEGGINGS, BOOTS, GAUNTLETS
}
