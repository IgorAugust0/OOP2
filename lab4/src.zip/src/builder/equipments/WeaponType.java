package builder.equipments;

/**
 * Enum que representa os tipos de armas.
 */
public enum WeaponType {
    SWORD, AXE, DAGGER, STAFF, BOW, CROSSBOW, WAND
}
