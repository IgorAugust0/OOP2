package builder.attributes;

/**
 * Classe enum que representa o gênero do personagem.
 */
public enum Gender {
    MALE, FEMALE, NON_BINARY
}
