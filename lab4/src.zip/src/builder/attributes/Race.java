package builder.attributes;

/**
 * Classe enum que representa a raça do personagem.
 */
public enum Race {
    HUMAN, ELF, DWARF, ORC, HALFLING, GNOME
}
